<?php

include "creator.php";
include "flag.php";

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>PDF Creator!</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="jumbotron.css" rel="stylesheet">
  </head>

  <body>

    

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">PDF Convertion. Cause its cool!</h1>
          <p>Upload an image file and embedd it into a nice PDF</p>
        </div>
      </div>

      <div class="container">
        <!-- Example row of columns -->
        <div class="row">
		<form action="index.php" method="post" enctype="multipart/form-data">
          <div class="input-group">
			  <div class="input-group-prepend">
				<span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
				</div>
				 <div class="custom-file"> 
					<input type="file" class="custom-file-input" name="file" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
					<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
				  </div>
				  
				</div>
		  <button type="submit" class="btn btn-primary">Submit</button>
</form>
        </div>

        <hr>

      </div> <!-- /container -->
	  <?php
define ('SITE_ROOT', realpath(dirname(__FILE__)));

if (isset($_FILES["file"]))
{
	$upload_folder = getcwd() . '/upload/';
	$filename = md5(pathinfo($_FILES['file']['name'], PATHINFO_FILENAME));
	$extension = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
	 
	 
	//Überprüfung der Dateiendung
	$allowed_extensions = array('png', 'jpg', 'jpeg', 'gif');
	if(!in_array($extension, $allowed_extensions)) {
	 die("<div class=\"container\">Invalid image extension!</div>");
	 return;
	}
	 
	//Überprüfung der Dateigröße
	$max_size = 500*1024; //500 KB
	if($_FILES['file']['size'] > $max_size) {
	 echo("<div class=\"container\">No files > 500 KB!</div>");
	 return;
	}
	 
	//Überprüfung dass das Bild keine Fehler enthält
	if(function_exists('exif_imagetype')) { //Die exif_imagetype-Funktion erfordert die exif-Erweiterung auf dem Server
	 $allowed_types = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
	 $detected_type = exif_imagetype($_FILES['file']['tmp_name']);
	 
	 
	 if(!in_array($detected_type, $allowed_types)) {
	 echo("<div class=\"container\">Only pictures allowed!</div>");
	 return;
	 }
	}
	 
	//Pfad zum Upload
	$new_path = $upload_folder.$filename.'.'.$extension;
	$new_path_browser = 'upload/'.$filename.'.'.$extension;
	 
	//Neuer Dateiname falls die Datei bereits existiert
	if(file_exists($new_path)) { //Falls Datei existiert, hänge eine Zahl an den Dateinamen
	 $id = 1;
	 do {
	 $new_path = $upload_folder.$filename.'_'.$id.'.'.$extension;
	 $new_path_browser = 'upload/'.$filename.'_'.$id.'.'.$extension;
	 $id++;
	 } while(file_exists($new_path));
	}
	
	if (!file_exists('upload')) {
		mkdir('upload', 0777, true);
	}
	 
	//Alles okay, verschiebe Datei an neuen Pfad
	move_uploaded_file($_FILES['file']['tmp_name'], $new_path);
	echo '<div class="container"><div class="alert alert-success" role="alert">
	  Upload successful: <a href="'.$new_path_browser . '">'.$new_path_browser.'</a></div></div>
	  
	  <div class="container">
	  <form action="index.php" method="post">
	  <div class="form-group">
	  <label for="exampleFormControlTextarea3">PDF Document HTML Input:</label>
	  <textarea class="form-control" name="pdfcontent" id="exampleFormControlTextarea3" rows="7">';
	  ?> <h1>Converted by CoolPDF</h1><h3>We hope you enjoyed our service!</h3>
	 <?php echo '<img src="'.$new_path_browser . '">
	  </textarea>
	   </div>
	   <button type="submit" class="btn btn-primary">Submit</button>
	  </form>
	  </div>';
}
else if (isset($_POST["pdfcontent"]))
{
	$creator = new \PDFStuff\PDFCreator();
	$creator->createPdf($_POST["pdfcontent"]);
}
?>
    </main>

    <footer class="container">
      <p>&copy; CoolCompany 2017-2018</p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="js/vendor/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
