<?php

$flag = "ALLES{stuff}";
